package util;

import org.hibernate.SessionFactory;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.engine.jdbc.connections.spi.ConnectionProvider;
import org.hibernate.engine.spi.SessionFactoryImplementor;
import org.hibernate.service.ServiceRegistry;
import org.hibernate.service.spi.Stoppable;

public class HibernateUtil {

    private static final SessionFactory sessionFactory = buildSessionFactory();

    private static SessionFactory buildSessionFactory() {
        try {
            // Create the SessionFactory from hibernate.cfg.xml
            Configuration cfg = new Configuration();
            cfg.configure();
         /*   StandardServiceRegistryBuilder  builder = new StandardServiceRegistryBuilder();
            builder.applySettings(cfg.getProperties());
            ServiceRegistry sregistry = builder.build();  */
            return cfg.buildSessionFactory();
        }
        catch (Throwable ex) {
            // Make sure you log the exception, as it might be swallowed
            System.err.println("Initial SessionFactory creation failed." + ex);
            throw new ExceptionInInitializerError(ex);
        }
    }

    public static SessionFactory getSessionFactory() {
        return sessionFactory;
    }

    public static void close()
    {
    	sessionFactory.close();
    	   final SessionFactoryImplementor sessionFactoryImplementor = (SessionFactoryImplementor) sessionFactory;
    	    ConnectionProvider connectionProvider = sessionFactoryImplementor.getConnectionProvider();
    	    if (Stoppable.class.isInstance(connectionProvider)) {
    	        ((Stoppable) connectionProvider).stop();
    	    } 
    }
}